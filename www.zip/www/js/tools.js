function openUrlInExternal(url) {
	window.open(url, "_system");
	return false;
}